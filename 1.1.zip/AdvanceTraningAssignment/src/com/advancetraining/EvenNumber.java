package com.advancetraining;

import java.util.Scanner;

public class EvenNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in); 
		int i,number;
		System.out.println("enter the even number:");
		number = sc.nextInt();
		for(i=0;i<=number;i++)
		{if(i%2==0) {
			System.out.println(i+"\n");
			
		}
			
		}

	}

}
